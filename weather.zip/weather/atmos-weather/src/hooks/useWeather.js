import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  fetchCurrentWeatherByCity,
  fetchCurrentWeatherByCoords,
  fetchForecastByCoords,
  hasWeatherApiKey,
  WeatherApiError,
} from '../services/weatherApi';
import {
  FAVORITES_STORAGE_KEY,
  RECENTS_STORAGE_KEY,
  UNIT_STORAGE_KEY,
  getStoredValue,
  groupForecastByDay,
  normalizeCityKey,
  setStoredValue,
} from '../utils/weatherHelpers';

const MAX_RECENTS = 6;

function toLocationFromCurrent(data) {
  return {
    name: data?.name || 'Unknown location',
    country: data?.sys?.country || '',
    lat: data?.coord?.lat,
    lon: data?.coord?.lon,
  };
}

export function useWeather() {
  const [currentWeather, setCurrentWeather] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [dailyForecast, setDailyForecast] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [unit, setUnit] = useState(() => getStoredValue(UNIT_STORAGE_KEY, 'metric'));
  const [favorites, setFavorites] = useState(() => getStoredValue(FAVORITES_STORAGE_KEY, []));
  const [recents, setRecents] = useState(() => getStoredValue(RECENTS_STORAGE_KEY, []));
  const [lastUpdated, setLastUpdated] = useState(null);
  const [status, setStatus] = useState(hasWeatherApiKey() ? 'idle' : 'missing_key');
  const lastRequestRef = useRef(null);

  useEffect(() => {
    setStoredValue(UNIT_STORAGE_KEY, unit);
  }, [unit]);

  useEffect(() => {
    setStoredValue(FAVORITES_STORAGE_KEY, favorites);
  }, [favorites]);

  useEffect(() => {
    setStoredValue(RECENTS_STORAGE_KEY, recents);
  }, [recents]);

  const upsertRecent = useCallback((location) => {
    if (!location?.name) return;
    setRecents((prev) => {
      const key = normalizeCityKey(location.name, location.country);
      const filtered = prev.filter((item) => normalizeCityKey(item.name, item.country) !== key);
      return [{ ...location }, ...filtered].slice(0, MAX_RECENTS);
    });
  }, []);

  const applyWeatherData = useCallback((current, forecastData) => {
    setCurrentWeather(current);
    setForecast(forecastData);
    const tz = forecastData?.city?.timezone ?? current?.timezone ?? 0;
    setDailyForecast(groupForecastByDay(forecastData?.list || [], tz));
    const location = toLocationFromCurrent(current);
    upsertRecent(location);
    setLastUpdated(new Date().toISOString());
    setStatus('live');
  }, [upsertRecent]);

  const runRequest = useCallback(async (requestFn, requestMeta) => {
    setLoading(true);
    setError(null);
    setStatus('loading');
    lastRequestRef.current = requestMeta;
    try {
      const current = await requestFn();
      const { lat, lon } = current.coord || {};
      const forecastData = await fetchForecastByCoords(lat, lon);
      applyWeatherData(current, forecastData);
    } catch (err) {
      const apiError = err instanceof WeatherApiError
        ? err
        : new WeatherApiError(err?.message || 'Something went wrong while fetching weather data.', { type: 'unknown' });
      setError({ message: apiError.message, type: apiError.type, status: apiError.status });
      setStatus(apiError.type === 'missing_key' ? 'missing_key' : 'error');
    } finally {
      setLoading(false);
    }
  }, [applyWeatherData]);

  const searchCity = useCallback(async (city) => {
    const trimmed = (city || '').trim();
    if (!trimmed) {
      setError({ message: 'Please enter a city name to search.', type: 'empty' });
      setStatus('error');
      return;
    }
    await runRequest(() => fetchCurrentWeatherByCity(trimmed), { type: 'city', value: trimmed });
  }, [runRequest]);

  const searchCoords = useCallback(async (lat, lon, label) => {
    if (lat == null || lon == null) {
      setError({ message: 'Location coordinates are unavailable.', type: 'invalid_location' });
      setStatus('error');
      return;
    }
    await runRequest(() => fetchCurrentWeatherByCoords(lat, lon), { type: 'coords', value: { lat, lon, label } });
  }, [runRequest]);

  const searchByCurrentLocation = useCallback(() => {
    if (!('geolocation' in navigator)) {
      setError({ message: 'Geolocation is not supported by your browser.', type: 'geolocation' });
      setStatus('error');
      return;
    }
    setLoading(true);
    setError(null);
    setStatus('loading');
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        await searchCoords(latitude, longitude, 'Current location');
      },
      (geoError) => {
        let message = 'Unable to retrieve your current location.';
        if (geoError?.code === 1) message = 'Location permission was denied. Please allow access or search for a city.';
        if (geoError?.code === 2) message = 'Location information is unavailable. Please try again or search for a city.';
        if (geoError?.code === 3) message = 'Location request timed out. Please try again.';
        setError({ message, type: 'geolocation' });
        setStatus('error');
        setLoading(false);
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
    );
  }, [searchCoords]);

  const refresh = useCallback(async () => {
    const last = lastRequestRef.current;
    if (!last) {
      if (currentWeather?.coord) {
        await searchCoords(currentWeather.coord.lat, currentWeather.coord.lon, 'Refresh');
      }
      return;
    }
    if (last.type === 'city') {
      await searchCity(last.value);
    } else if (last.type === 'coords') {
      await searchCoords(last.value.lat, last.value.lon, last.value.label);
    }
  }, [currentWeather, searchCity, searchCoords]);

  const retry = useCallback(async () => {
    if (lastRequestRef.current) {
      await refresh();
    } else {
      setError(null);
      setStatus(hasWeatherApiKey() ? 'idle' : 'missing_key');
    }
  }, [refresh]);

  const toggleUnit = useCallback(() => {
    setUnit((prev) => (prev === 'metric' ? 'imperial' : 'metric'));
  }, []);

  const setUnitValue = useCallback((value) => {
    setUnit(value === 'imperial' ? 'imperial' : 'metric');
  }, []);

  const addFavorite = useCallback((location) => {
    if (!location?.name) return;
    setFavorites((prev) => {
      const key = normalizeCityKey(location.name, location.country);
      if (prev.some((item) => normalizeCityKey(item.name, item.country) === key)) return prev;
      return [{ ...location }, ...prev].slice(0, 12);
    });
  }, []);

  const removeFavorite = useCallback((location) => {
    const key = normalizeCityKey(location?.name, location?.country);
    setFavorites((prev) => prev.filter((item) => normalizeCityKey(item.name, item.country) !== key));
  }, []);

  const isFavorite = useCallback((location) => {
    const key = normalizeCityKey(location?.name, location?.country);
    return favorites.some((item) => normalizeCityKey(item.name, item.country) === key);
  }, [favorites]);

  const clearError = useCallback(() => setError(null), []);

  const location = useMemo(() => (currentWeather ? toLocationFromCurrent(currentWeather) : null), [currentWeather]);

  return {
    currentWeather,
    forecast,
    dailyForecast,
    loading,
    error,
    unit,
    favorites,
    recents,
    lastUpdated,
    status,
    location,
    hasApiKey: hasWeatherApiKey(),
    searchCity,
    searchCoords,
    searchByCurrentLocation,
    refresh,
    retry,
    toggleUnit,
    setUnit: setUnitValue,
    addFavorite,
    removeFavorite,
    isFavorite,
    clearError,
  };
}
