export const UNIT_STORAGE_KEY = 'atmos_unit';
export const FAVORITES_STORAGE_KEY = 'atmos_favorites';
export const RECENTS_STORAGE_KEY = 'atmos_recents';

export function getStoredValue(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export function setStoredValue(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore storage failures
  }
}

export function toFahrenheit(celsius) {
  return (celsius * 9) / 5 + 32;
}

export function toMph(kmh) {
  return kmh / 1.609344;
}

export function formatTemperature(valueC, unit) {
  if (valueC == null || Number.isNaN(valueC)) return '--';
  const value = unit === 'imperial' ? toFahrenheit(valueC) : valueC;
  const suffix = unit === 'imperial' ? '°F' : '°C';
  return `${Math.round(value)}${suffix}`;
}

export function formatWind(speedMs, unit) {
  if (speedMs == null || Number.isNaN(speedMs)) return '--';
  const kmh = speedMs * 3.6;
  if (unit === 'imperial') {
    return `${Math.round(toMph(kmh))} mph`;
  }
  return `${Math.round(kmh)} km/h`;
}

export function formatPressure(hPa) {
  if (hPa == null) return '--';
  return `${Math.round(hPa)} hPa`;
}

export function formatVisibility(meters) {
  if (meters == null) return '--';
  if (meters >= 1000) return `${(meters / 1000).toFixed(1)} km`;
  return `${Math.round(meters)} m`;
}

export function formatHumidity(value) {
  if (value == null) return '--';
  return `${Math.round(value)}%`;
}

export function formatWindDirection(deg) {
  if (deg == null || Number.isNaN(deg)) return '--';
  const dirs = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const index = Math.round(deg / 22.5) % 16;
  return `${dirs[index]} (${Math.round(deg)}°)`;
}

export function formatUnixTime(unixSeconds, timezoneOffsetSeconds = 0) {
  if (!unixSeconds) return '--';
  const date = new Date((unixSeconds + timezoneOffsetSeconds) * 1000);
  return date.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  });
}

export function formatLocalDateTime(unixSeconds, timezoneOffsetSeconds = 0) {
  if (!unixSeconds) return '--';
  const date = new Date((unixSeconds + timezoneOffsetSeconds) * 1000);
  return date.toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  });
}

export function getWeatherTheme(conditionMain, isNight) {
  if (isNight) return 'night';
  const main = (conditionMain || '').toLowerCase();
  if (main.includes('clear')) return 'sunny';
  if (main.includes('cloud')) return 'cloudy';
  if (main.includes('rain') || main.includes('drizzle') || main.includes('thunder')) return 'rainy';
  if (main.includes('snow')) return 'snowy';
  if (main.includes('mist') || main.includes('fog') || main.includes('haze') || main.includes('smoke')) return 'cloudy';
  return 'sunny';
}

export function getWeatherIconType(conditionMain, isNight) {
  const main = (conditionMain || '').toLowerCase();
  if (isNight && main.includes('clear')) return 'moon';
  if (main.includes('thunder')) return 'thunder';
  if (main.includes('rain') || main.includes('drizzle')) return 'rain';
  if (main.includes('snow')) return 'snow';
  if (main.includes('cloud') || main.includes('mist') || main.includes('fog') || main.includes('haze')) return 'cloud';
  if (isNight) return 'moon';
  return 'sun';
}

export function isNightAtLocation(currentDt, sunrise, sunset) {
  if (currentDt == null || sunrise == null || sunset == null) return false;
  return currentDt < sunrise || currentDt >= sunset;
}

export function groupForecastByDay(list, timezoneOffsetSeconds = 0) {
  if (!Array.isArray(list)) return [];
  const days = new Map();

  list.forEach((item) => {
    const local = new Date((item.dt + timezoneOffsetSeconds) * 1000);
    const key = local.toISOString().slice(0, 10); // UTC slice but local shifted date
    if (!days.has(key)) days.set(key, []);
    days.get(key).push({ ...item, _local: local });
  });

  const result = [];
  for (const [dateKey, entries] of days.entries()) {
    let chosen = entries[0];
    let bestScore = Infinity;
    entries.forEach((entry) => {
      const hour = entry._local.getUTCHours();
      const score = Math.abs(12 - hour);
      if (score < bestScore) {
        bestScore = score;
        chosen = entry;
      }
    });

    const temps = entries.map((e) => e.main?.temp).filter((t) => typeof t === 'number');
    const min = temps.length ? Math.min(...temps) : chosen.main?.temp_min;
    const max = temps.length ? Math.max(...temps) : chosen.main?.temp_max;
    const weather = chosen.weather?.[0] || {};
    const iconCode = weather.icon || '';
    const isNight = iconCode.endsWith('n');

    result.push({
      dateKey,
      dt: chosen.dt,
      dayLabel: chosen._local.toLocaleDateString([], { weekday: 'short', timeZone: 'UTC' }),
      dateLabel: chosen._local.toLocaleDateString([], { month: 'short', day: 'numeric', timeZone: 'UTC' }),
      description: weather.description || 'Unknown',
      condition: weather.main || 'Clear',
      iconType: getWeatherIconType(weather.main, isNight),
      tempMinC: min,
      tempMaxC: max,
    });
  }

  // limit to next 5 distinct days
  return result.slice(0, 5);
}

export function getTemperatureIndicator(minC, maxC, unit) {
  const min = unit === 'imperial' ? toFahrenheit(minC ?? 0) : (minC ?? 0);
  const max = unit === 'imperial' ? toFahrenheit(maxC ?? 0) : (maxC ?? 0);
  const span = Math.max(1, max - min);
  const width = Math.min(100, Math.max(20, span * 4));
  return { min: Math.round(min), max: Math.round(max), width };
}

export function normalizeCityKey(name, country) {
  return `${(name || '').trim().toLowerCase()}|${(country || '').trim().toLowerCase()}`;
}
