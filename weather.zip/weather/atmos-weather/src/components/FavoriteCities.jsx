import { Star, Clock3, Trash2, MapPin } from 'lucide-react';

function formatLocation(item) {
  return `${item.name}${item.country ? `, ${item.country}` : ''}`;
}

export default function FavoriteCities({ favorites = [], recents = [], onSelect, onRemoveFavorite }) {
  return (
    <div className="favorites-panel glass-card">
      <div className="panel-header">
        <h3>Saved & Recent</h3>
      </div>

      <div className="favorites-section">
        <h4><Star size={16} /> Favorite cities</h4>
        {favorites.length === 0 ? (
          <p className="muted">No favorite cities saved yet. Search for a city and save it from the weather dashboard.</p>
        ) : (
          <ul className="saved-list">
            {favorites.map((fav) => (
              <li key={`${fav.name}-${fav.country}-${fav.lat}-${fav.lon}`} className="saved-item">
                <button type="button" className="saved-select" onClick={() => onSelect(fav)}>
                  <MapPin size={15} />
                  <span>{formatLocation(fav)}</span>
                </button>
                <button
                  type="button"
                  className="icon-button ghost-button"
                  aria-label={`Remove ${formatLocation(fav)} from favorites`}
                  onClick={() => onRemoveFavorite(fav)}
                >
                  <Trash2 size={15} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="favorites-section">
        <h4><Clock3 size={16} /> Recent searches</h4>
        {recents.length === 0 ? (
          <p className="muted">Your recent searches will appear here.</p>
        ) : (
          <ul className="saved-list">
            {recents.map((item) => (
              <li key={`${item.name}-${item.country}-${item.lat}-${item.lon}`} className="saved-item">
                <button type="button" className="saved-select" onClick={() => onSelect(item)}>
                  <MapPin size={15} />
                  <span>{formatLocation(item)}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
