import { LoaderCircle } from 'lucide-react';

export default function Loading({ label = 'Loading...', inline = false }) {
  return (
    <div className={`loading-state ${inline ? 'inline' : ''}`} role="status" aria-live="polite">
      <LoaderCircle className="spin" size={inline ? 18 : 28} />
      <span>{label}</span>
    </div>
  );
}

export function SkeletonDashboard({ variant = 'weather' }) {
  if (variant === 'forecast') {
    return (
      <div className="skeleton-grid forecast">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="skeleton-card glass-card">
            <div className="skeleton line short" />
            <div className="skeleton circle" />
            <div className="skeleton line" />
            <div className="skeleton line medium" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="skeleton-dashboard">
      <div className="skeleton-card glass-card hero-skeleton">
        <div className="skeleton line short" />
        <div className="skeleton line title" />
        <div className="skeleton line medium" />
      </div>
      <div className="skeleton-grid metrics">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="skeleton-card glass-card">
            <div className="skeleton line short" />
            <div className="skeleton line medium" />
          </div>
        ))}
      </div>
    </div>
  );
}
