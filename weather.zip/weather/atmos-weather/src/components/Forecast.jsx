import { Sun, Cloud, CloudRain, CloudLightning, CloudSnow, Moon } from 'lucide-react';
import { formatTemperature, getTemperatureIndicator } from '../utils/weatherHelpers';

function ForecastIcon({ type }) {
  const size = 34;
  switch (type) {
    case 'rain': return <CloudRain size={size} />;
    case 'thunder': return <CloudLightning size={size} />;
    case 'snow': return <CloudSnow size={size} />;
    case 'cloud': return <Cloud size={size} />;
    case 'moon': return <Moon size={size} />;
    case 'sun':
    default: return <Sun size={size} />;
  }
}

export default function Forecast({ days, unit }) {
  if (!days?.length) return null;

  return (
    <div className="forecast-grid">
      {days.map((day) => {
        const indicator = getTemperatureIndicator(day.tempMinC, day.tempMaxC, unit);
        return (
          <article key={day.dateKey} className="forecast-card glass-card">
            <div className="forecast-date">
              <p className="forecast-day">{day.dayLabel}</p>
              <p className="forecast-full-date">{day.dateLabel}</p>
            </div>
            <div className={`forecast-icon icon-${day.iconType}`}>
              <ForecastIcon type={day.iconType} />
            </div>
            <p className="forecast-description">{day.description}</p>
            <div className="forecast-temps">
              <span className="temp-max">H: {formatTemperature(day.tempMaxC, unit)}</span>
              <span className="temp-min">L: {formatTemperature(day.tempMinC, unit)}</span>
            </div>
            <div className="temp-indicator" aria-label={`Temperature range ${indicator.min} to ${indicator.max}`}>
              <div className="temp-indicator-track">
                <div className="temp-indicator-bar" style={{ width: `${indicator.width}%` }} />
              </div>
              <div className="temp-indicator-labels">
                <span>{indicator.min}°</span>
                <span>{indicator.max}°</span>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
}
