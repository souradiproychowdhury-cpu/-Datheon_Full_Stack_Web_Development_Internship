import { CloudSun, Map, Settings, Home, CloudRain, Activity } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'weather', label: 'Weather', icon: CloudSun },
  { id: 'forecast', label: 'Forecast', icon: CloudRain },
  { id: 'map', label: 'Map', icon: Map },
  { id: 'settings', label: 'Settings', icon: Settings },
];

function statusLabel(status) {
  switch (status) {
    case 'live': return 'Live';
    case 'loading': return 'Updating';
    case 'error': return 'Error';
    case 'missing_key': return 'Setup needed';
    default: return 'Ready';
  }
}

export default function Navbar({ activeSection, onNavigate, status, onOpenSettings }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNav = (id) => {
    if (id === 'settings') onOpenSettings?.();
    else onNavigate(id);
    setMenuOpen(false);
  };

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <button className="brand" onClick={() => handleNav('home')} aria-label="Go to home">
          <span className="brand-mark">A</span>
          <span className="brand-text">ATMOS</span>
        </button>

        <button
          className="menu-toggle"
          onClick={() => setMenuOpen((v) => !v)}
          aria-expanded={menuOpen}
          aria-label="Toggle navigation"
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`nav-links ${menuOpen ? 'open' : ''}`} aria-label="Primary">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`nav-link ${activeSection === id ? 'active' : ''}`}
              onClick={() => handleNav(id)}
            >
              <Icon size={16} aria-hidden="true" />
              <span>{label}</span>
            </button>
          ))}
        </nav>

        <div className={`live-indicator status-${status}`} title={`Weather status: ${statusLabel(status)}`}>
          <Activity size={14} aria-hidden="true" />
          <span className="live-dot" aria-hidden="true" />
          <span className="live-text">{statusLabel(status)}</span>
        </div>
      </div>
    </header>
  );
}
