import { useEffect, useRef, useState } from 'react';
import { MapPin, AlertCircle } from 'lucide-react';
import { hasGoogleMapsApiKey, loadGoogleMapsApi } from '../services/mapsApi';

export default function WeatherMap({ location, onSelectLocation }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const clickListenerRef = useRef(null);
  const [status, setStatus] = useState(hasGoogleMapsApiKey() ? 'loading' : 'no_key');
  const [error, setError] = useState('');

  const center = location?.lat != null && location?.lon != null
    ? { lat: location.lat, lng: location.lon }
    : { lat: 20, lng: 0 };
  const hasLocation = location?.lat != null && location?.lon != null;

  useEffect(() => {
    let cancelled = false;
    if (!hasGoogleMapsApiKey()) {
      setStatus('no_key');
      return undefined;
    }

    setStatus('loading');
    loadGoogleMapsApi()
      .then((maps) => {
        if (cancelled || !containerRef.current) return;
        if (!mapRef.current) {
          mapRef.current = new maps.Map(containerRef.current, {
            center,
            zoom: hasLocation ? 10 : 2,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: true,
            clickableIcons: false,
            backgroundColor: '#0b1220',
          });
        }
        setStatus('ready');
      })
      .catch((err) => {
        if (cancelled) return;
        setError(err?.message || 'Google Maps could not be loaded.');
        setStatus('error');
      });

    return () => {
      cancelled = true;
    };
  }, []); // init once

  useEffect(() => {
    if (status !== 'ready' || !mapRef.current || !window.google?.maps) return;
    const maps = window.google.maps;

    if (clickListenerRef.current) {
      maps.event.removeListener(clickListenerRef.current);
    }
    clickListenerRef.current = mapRef.current.addListener('click', (e) => {
      const lat = e.latLng?.lat?.();
      const lon = e.latLng?.lng?.();
      if (typeof lat === 'number' && typeof lon === 'number') {
        onSelectLocation?.(lat, lon);
      }
    });

    return () => {
      if (clickListenerRef.current) {
        maps.event.removeListener(clickListenerRef.current);
        clickListenerRef.current = null;
      }
    };
  }, [status, onSelectLocation]);

  useEffect(() => {
    if (status !== 'ready' || !mapRef.current || !window.google?.maps) return;
    const maps = window.google.maps;

    if (hasLocation) {
      mapRef.current.panTo(center);
      mapRef.current.setZoom(10);
      const title = `${location.name || 'Selected location'}${location.country ? `, ${location.country}` : ''}`;
      if (!markerRef.current) {
        markerRef.current = new maps.Marker({
          map: mapRef.current,
          position: center,
          title,
          animation: maps.Animation.DROP,
        });
      } else {
        markerRef.current.setPosition(center);
        markerRef.current.setTitle(title);
      }
    } else if (markerRef.current) {
      markerRef.current.setMap(null);
      markerRef.current = null;
      mapRef.current.setCenter({ lat: 20, lng: 0 });
      mapRef.current.setZoom(2);
    }
  }, [status, location, hasLocation, center.lat, center.lng]);

  if (status === 'no_key') {
    return (
      <div className="map-fallback glass-card">
        <MapPin size={28} />
        <h3>Google Maps is not configured</h3>
        <p>
          Add <code>VITE_GOOGLE_MAPS_API_KEY</code> to enable the interactive weather map. You can continue using city search and current location features without it.
        </p>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="map-fallback glass-card">
        <AlertCircle size={28} />
        <h3>Map unavailable</h3>
        <p>{error || 'Google Maps could not be loaded right now.'} Weather search and forecasts remain fully available.</p>
      </div>
    );
  }

  return (
    <div className="map-container glass-card">
      <div className="map-header">
        <div>
          <h3>{hasLocation ? `${location.name}${location.country ? `, ${location.country}` : ''}` : 'Select a location'}</h3>
          <p>{hasLocation ? 'Click anywhere on the map to load weather for a different location.' : 'Search for a city or click on the map to choose a location.'}</p>
        </div>
        {hasLocation && (
          <div className="map-coords">
            <span>{location.lat.toFixed(3)}, {location.lon.toFixed(3)}</span>
          </div>
        )}
      </div>
      <div className="map-frame-wrap">
        {status === 'loading' && <div className="map-loading">Loading Google Maps…</div>}
        <div ref={containerRef} className="map-frame" aria-label="Interactive weather map" />
      </div>
    </div>
  );
}
