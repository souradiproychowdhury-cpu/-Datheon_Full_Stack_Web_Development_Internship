import { Droplets, Wind, Gauge, Eye, Sunrise, Sunset, Compass } from 'lucide-react';
import {
  formatHumidity,
  formatPressure,
  formatVisibility,
  formatWind,
  formatWindDirection,
  formatUnixTime,
} from '../utils/weatherHelpers';

export default function WeatherMetrics({ data, unit }) {
  if (!data) return null;
  const main = data.main || {};
  const wind = data.wind || {};
  const sys = data.sys || {};
  const timezone = data.timezone || 0;

  const metrics = [
    { label: 'Humidity', value: formatHumidity(main.humidity), icon: Droplets },
    { label: 'Wind speed', value: formatWind(wind.speed, unit), icon: Wind },
    { label: 'Wind direction', value: formatWindDirection(wind.deg), icon: Compass },
    { label: 'Atmospheric pressure', value: formatPressure(main.pressure), icon: Gauge },
    { label: 'Visibility', value: formatVisibility(data.visibility), icon: Eye },
    { label: 'Sunrise', value: formatUnixTime(sys.sunrise, timezone), icon: Sunrise },
    { label: 'Sunset', value: formatUnixTime(sys.sunset, timezone), icon: Sunset },
  ];

  return (
    <div className="metrics-grid">
      {metrics.map(({ label, value, icon: Icon }) => (
        <div key={label} className="metric-card glass-card">
          <div className="metric-icon"><Icon size={18} /></div>
          <div className="metric-content">
            <p className="metric-label">{label}</p>
            <p className="metric-value">{value}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
