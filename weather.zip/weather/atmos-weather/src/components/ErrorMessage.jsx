import { AlertTriangle, RefreshCw, KeyRound, WifiOff, Clock3, X } from 'lucide-react';

function iconForType(type) {
  switch (type) {
    case 'missing_key':
    case 'unauthorized':
      return KeyRound;
    case 'network':
      return WifiOff;
    case 'rate_limit':
      return Clock3;
    default:
      return AlertTriangle;
  }
}

export default function ErrorMessage({ message, type = 'unknown', onRetry, onDismiss, loading = false }) {
  const Icon = iconForType(type);
  const canRetry = typeof onRetry === 'function' && type !== 'missing_key' && type !== 'empty';

  return (
    <div className={`error-banner glass-card error-${type}`} role="alert">
      <div className="error-icon-wrap">
        <Icon size={20} />
      </div>
      <div className="error-content">
        <h3>Weather update issue</h3>
        <p>{message}</p>
      </div>
      <div className="error-actions">
        {canRetry && (
          <button className="ghost-button" onClick={onRetry} disabled={loading}>
            <RefreshCw size={16} className={loading ? 'spin' : ''} />
            Retry
          </button>
        )}
        {onDismiss && (
          <button className="icon-button ghost-button" onClick={onDismiss} aria-label="Dismiss error">
            <X size={16} />
          </button>
        )}
      </div>
    </div>
  );
}
