import { useEffect, useRef, useState } from 'react';
import { Search, LocateFixed, LoaderCircle } from 'lucide-react';
import { hasGoogleMapsApiKey, loadGoogleMapsApi } from '../services/mapsApi';

export default function SearchBar({ onSearch, onUseCurrentLocation, loading, quickCities = [], recentSearches = [] }) {
  const [query, setQuery] = useState('');
  const [placesReady, setPlacesReady] = useState(false);
  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);
  const selectedFromPlacesRef = useRef(false);

  useEffect(() => {
    let mounted = true;
    if (!hasGoogleMapsApiKey()) return undefined;

    loadGoogleMapsApi()
      .then((maps) => {
        if (!mounted || !inputRef.current || !maps?.places?.Autocomplete) return;
        autocompleteRef.current = new maps.places.Autocomplete(inputRef.current, {
          types: ['(cities)'],
          fields: ['name', 'formatted_address', 'geometry', 'address_components'],
        });
        autocompleteRef.current.addListener('place_changed', () => {
          const place = autocompleteRef.current.getPlace();
          const name = place?.name || place?.formatted_address || inputRef.current?.value || '';
          if (name) {
            selectedFromPlacesRef.current = true;
            setQuery(name);
            onSearch(name);
          }
        });
        setPlacesReady(true);
      })
      .catch(() => {
        if (mounted) setPlacesReady(false);
      });

    return () => {
      mounted = false;
      if (autocompleteRef.current && window.google?.maps?.event) {
        window.google.maps.event.clearInstanceListeners(autocompleteRef.current);
      }
    };
  }, [onSearch]);

  const submit = (e) => {
    e?.preventDefault();
    if (selectedFromPlacesRef.current) {
      selectedFromPlacesRef.current = false;
      return;
    }
    onSearch(query);
  };

  return (
    <div className="search-panel glass-card">
      <form className="search-form" onSubmit={submit}>
        <div className="search-input-wrap">
          <Search size={18} className="search-icon" aria-hidden="true" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search any city worldwide..."
            aria-label="Search for a city"
            autoComplete="off"
          />
        </div>
        <button type="submit" className="primary-button" disabled={loading}>
          {loading ? <><LoaderCircle size={16} className="spin" /> Searching</> : 'Search'}
        </button>
        <button
          type="button"
          className="ghost-button icon-button"
          onClick={onUseCurrentLocation}
          title="Use current location"
          aria-label="Use current location"
          disabled={loading}
        >
          <LocateFixed size={18} />
        </button>
      </form>

      <div className="search-meta">
        <div className="quick-search">
          <span className="meta-label">Quick search</span>
          <div className="chip-row">
            {quickCities.map((city) => (
              <button key={city} type="button" className="chip" onClick={() => { setQuery(city); onSearch(city); }}>
                {city}
              </button>
            ))}
          </div>
        </div>

        {recentSearches?.length > 0 && (
          <div className="recent-search">
            <span className="meta-label">Recent</span>
            <div className="chip-row">
              {recentSearches.slice(0, 5).map((item) => {
                const label = `${item.name}${item.country ? `, ${item.country}` : ''}`;
                return (
                  <button key={label} type="button" className="chip subtle" onClick={() => { setQuery(label); onSearch(label); }}>
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {placesReady && <p className="places-hint">Autocomplete suggestions enabled.</p>}
    </div>
  );
}
