import {
  Sun, Cloud, CloudRain, CloudLightning, CloudSnow, Moon, Star, RefreshCw, MapPin, Clock3,
} from 'lucide-react';
import { formatTemperature } from '../utils/weatherHelpers';

function WeatherIcon({ type, className = '' }) {
  const size = 72;
  switch (type) {
    case 'rain': return <CloudRain size={size} className={className} />;
    case 'thunder': return <CloudLightning size={size} className={className} />;
    case 'snow': return <CloudSnow size={size} className={className} />;
    case 'cloud': return <Cloud size={size} className={className} />;
    case 'moon': return <Moon size={size} className={className} />;
    case 'sun':
    default: return <Sun size={size} className={className} />;
  }
}

export default function CurrentWeather({
  data,
  unit,
  iconType,
  lastUpdated,
  isFavorite,
  onToggleFavorite,
  onRefresh,
  loading,
}) {
  if (!data) return null;

  const weather = data.weather?.[0] || {};
  const main = data.main || {};
  const locationLabel = `${data.name || 'Unknown'}${data.sys?.country ? `, ${data.sys.country}` : ''}`;
  const updatedLabel = lastUpdated ? new Date(lastUpdated).toLocaleString() : '—';

  return (
    <article className="current-weather glass-card">
      <div className="current-main">
        <div className="current-icon-wrap">
          <div className={`weather-icon-animated icon-${iconType}`}>
            <WeatherIcon type={iconType} />
          </div>
        </div>
        <div className="current-primary">
          <div className="location-row">
            <MapPin size={16} aria-hidden="true" />
            <span>{locationLabel}</span>
          </div>
          <div className="temperature-row">
            <span className="temperature-value">{formatTemperature(main.temp, unit)}</span>
            <div className="condition-block">
              <p className="condition-main">{weather.main || '—'}</p>
              <p className="condition-description">{weather.description || 'No description available'}</p>
            </div>
          </div>
          <div className="temp-range">
            <span>High: <strong>{formatTemperature(main.temp_max, unit)}</strong></span>
            <span>Low: <strong>{formatTemperature(main.temp_min, unit)}</strong></span>
            <span>Feels like: <strong>{formatTemperature(main.feels_like, unit)}</strong></span>
          </div>
        </div>
      </div>

      <div className="current-meta">
        <div className="meta-item">
          <Clock3 size={15} aria-hidden="true" />
          <span>Last updated: {updatedLabel}</span>
        </div>
        <div className="meta-actions">
          <button className={`ghost-button ${isFavorite ? 'active-favorite' : ''}`} onClick={onToggleFavorite} type="button">
            <Star size={16} fill={isFavorite ? 'currentColor' : 'none'} />
            {isFavorite ? 'Saved' : 'Save favorite'}
          </button>
          <button className="ghost-button" onClick={onRefresh} type="button" disabled={loading}>
            <RefreshCw size={16} className={loading ? 'spin' : ''} />
            Refresh
          </button>
        </div>
      </div>
    </article>
  );
}
