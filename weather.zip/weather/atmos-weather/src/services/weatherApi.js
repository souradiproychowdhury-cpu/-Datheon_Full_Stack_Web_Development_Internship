const BASE_URL = 'https://api.openweathermap.org/data/2.5';

export class WeatherApiError extends Error {
  constructor(message, { type = 'unknown', status = null } = {}) {
    super(message);
    this.name = 'WeatherApiError';
    this.type = type;
    this.status = status;
  }
}

function getApiKey() {
  return import.meta.env.VITE_OPENWEATHER_API_KEY;
}

export function hasWeatherApiKey() {
  const key = getApiKey();
  return Boolean(key && key !== 'your_openweathermap_api_key');
}

async function request(path, params) {
  if (!hasWeatherApiKey()) {
    throw new WeatherApiError(
      'OpenWeatherMap API key is missing. Add VITE_OPENWEATHER_API_KEY to your .env file and restart the dev server.',
      { type: 'missing_key' }
    );
  }

  const url = new URL(`${BASE_URL}${path}`);
  Object.entries({ ...params, appid: getApiKey() }).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, value);
    }
  });

  let response;
  try {
    response = await fetch(url.toString());
  } catch {
    throw new WeatherApiError('Network connection error. Please check your internet connection and try again.', {
      type: 'network',
    });
  }

  let data = null;
  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok) {
    if (response.status === 404) {
      throw new WeatherApiError('City not found. Please check the spelling and try another location.', {
        type: 'not_found',
        status: 404,
      });
    }
    if (response.status === 429) {
      throw new WeatherApiError('API rate limit reached. Please wait a moment and try again.', {
        type: 'rate_limit',
        status: 429,
      });
    }
    if (response.status === 401 || response.status === 403) {
      throw new WeatherApiError('Weather API key is invalid or unauthorized. Please verify your OpenWeatherMap API key.', {
        type: 'unauthorized',
        status: response.status,
      });
    }
    if (response.status >= 500) {
      throw new WeatherApiError('Weather service is currently unavailable. Please try again shortly.', {
        type: 'service_unavailable',
        status: response.status,
      });
    }
    const message = data?.message ? `Unable to retrieve weather data: ${data.message}.` : 'Unable to retrieve weather data.';
    throw new WeatherApiError(message, { type: 'api_error', status: response.status });
  }

  return data;
}

export async function fetchCurrentWeatherByCity(city) {
  return request('/weather', { q: city, units: 'metric' });
}

export async function fetchCurrentWeatherByCoords(lat, lon) {
  return request('/weather', { lat, lon, units: 'metric' });
}

export async function fetchForecastByCoords(lat, lon) {
  return request('/forecast', { lat, lon, units: 'metric' });
}
