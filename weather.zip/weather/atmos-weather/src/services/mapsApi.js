let mapsLoadPromise = null;

export function hasGoogleMapsApiKey() {
  const key = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  return Boolean(key && key !== 'your_google_maps_api_key');
}

export function loadGoogleMapsApi() {
  if (!hasGoogleMapsApiKey()) {
    return Promise.reject(new Error('Google Maps API key is not configured.'));
  }
  if (typeof window !== 'undefined' && window.google?.maps) {
    return Promise.resolve(window.google.maps);
  }
  if (mapsLoadPromise) return mapsLoadPromise;

  mapsLoadPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-atmos-google-maps="true"]');
    if (existing) {
      existing.addEventListener('load', () => resolve(window.google.maps));
      existing.addEventListener('error', () => reject(new Error('Failed to load Google Maps.')));
      return;
    }

    const callbackName = '__atmosInitGoogleMaps';
    window[callbackName] = () => {
      resolve(window.google.maps);
      try {
        delete window[callbackName];
      } catch {
        window[callbackName] = undefined;
      }
    };

    const script = document.createElement('script');
    const key = encodeURIComponent(import.meta.env.VITE_GOOGLE_MAPS_API_KEY);
    script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places&callback=${callbackName}`;
    script.async = true;
    script.defer = true;
    script.dataset.atmosGoogleMaps = 'true';
    script.onerror = () => {
      mapsLoadPromise = null;
      reject(new Error('Failed to load Google Maps JavaScript API.'));
    };
    document.head.appendChild(script);
  });

  return mapsLoadPromise;
}
