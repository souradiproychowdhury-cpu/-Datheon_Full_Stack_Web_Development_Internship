import { useEffect, useMemo, useRef, useState } from 'react';
import Navbar from './components/Navbar';
import SearchBar from './components/SearchBar';
import CurrentWeather from './components/CurrentWeather';
import WeatherMetrics from './components/WeatherMetrics';
import Forecast from './components/Forecast';
import WeatherMap from './components/WeatherMap';
import FavoriteCities from './components/FavoriteCities';
import Loading, { SkeletonDashboard } from './components/Loading';
import ErrorMessage from './components/ErrorMessage';
import { useWeather } from './hooks/useWeather';
import { getWeatherIconType, getWeatherTheme, isNightAtLocation } from './utils/weatherHelpers';

const SECTION_IDS = ['home', 'weather', 'forecast', 'map', 'settings'];

function App() {
  const weather = useWeather();
  const [activeSection, setActiveSection] = useState('home');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const mapSelectRef = useRef(false);

  const {
    currentWeather,
    dailyForecast,
    loading,
    error,
    unit,
    favorites,
    recents,
    lastUpdated,
    status,
    location,
    hasApiKey,
    searchCity,
    searchCoords,
    searchByCurrentLocation,
    refresh,
    retry,
    setUnit,
    toggleUnit,
    addFavorite,
    removeFavorite,
    isFavorite,
    clearError,
  } = weather;

  const isNight = useMemo(() => {
    if (!currentWeather) return false;
    return isNightAtLocation(currentWeather.dt, currentWeather.sys?.sunrise, currentWeather.sys?.sunset);
  }, [currentWeather]);

  const theme = useMemo(() => {
    const condition = currentWeather?.weather?.[0]?.main;
    return getWeatherTheme(condition, isNight);
  }, [currentWeather, isNight]);

  const iconType = useMemo(() => {
    const condition = currentWeather?.weather?.[0]?.main;
    return getWeatherIconType(condition, isNight);
  }, [currentWeather, isNight]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) {
          setActiveSection(visible.target.id);
        }
      },
      { rootMargin: '-30% 0px -55% 0px', threshold: [0.2, 0.4, 0.6] }
    );

    SECTION_IDS.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setActiveSection(id);
    }
    if (id === 'settings') setSettingsOpen(true);
  };

  const handleSelectFavorite = (fav) => {
    if (fav?.lat != null && fav?.lon != null) {
      searchCoords(fav.lat, fav.lon, fav.name);
      scrollToSection('weather');
    } else if (fav?.name) {
      searchCity(`${fav.name}${fav.country ? `, ${fav.country}` : ''}`);
      scrollToSection('weather');
    }
  };

  const handleMapLocationSelect = (lat, lon) => {
    mapSelectRef.current = true;
    searchCoords(lat, lon, 'Map selection');
  };

  useEffect(() => {
    if (mapSelectRef.current && currentWeather && !loading) {
      mapSelectRef.current = false;
      scrollToSection('weather');
    }
  }, [currentWeather, loading]);

  const locationLabel = location ? `${location.name}${location.country ? `, ${location.country}` : ''}` : '';

  return (
    <div className={`app theme-${theme}`}>
      <div className="background-layer" aria-hidden="true" />
      <Navbar
        activeSection={activeSection}
        onNavigate={scrollToSection}
        status={status}
        onOpenSettings={() => {
          setSettingsOpen(true);
          scrollToSection('settings');
        }}
      />

      <main className="main-content">
        <section id="home" className="section hero-section">
          <div className="hero-copy">
            <p className="eyebrow">Live Weather Telemetry</p>
            <h1>ATMOS</h1>
            <p className="tagline">Feel the atmosphere. Discover your world.</p>
            <p className="hero-description">
              Real-time weather intelligence for any city worldwide, with live conditions, forecast insights, and interactive location mapping.
            </p>
          </div>

          <SearchBar
            onSearch={searchCity}
            onUseCurrentLocation={searchByCurrentLocation}
            loading={loading}
            quickCities={['Kolkata', 'London', 'Tokyo', 'New York', 'Dubai']}
            recentSearches={recents}
          />

          {!hasApiKey && (
            <div className="setup-banner" role="status">
              <h3>API key setup required</h3>
              <p>
                Add <code>VITE_OPENWEATHER_API_KEY</code> to your <code>.env</code> file and restart the dev server to enable live weather data.
                Google Maps is optional and can be enabled with <code>VITE_GOOGLE_MAPS_API_KEY</code>.
              </p>
            </div>
          )}

          {error && (
            <ErrorMessage
              message={error.message}
              type={error.type}
              onRetry={retry}
              onDismiss={() => clearError()}
              loading={loading}
            />
          )}

          {!currentWeather && !loading && !error && hasApiKey && (
            <div className="empty-state glass-card">
              <div className="empty-icon" aria-hidden="true">☁️</div>
              <h2>Start exploring the atmosphere</h2>
              <p>Search for a city, pick a quick suggestion, or use your current location to load live weather telemetry.</p>
            </div>
          )}

          {loading && !currentWeather && <Loading label="Retrieving live weather data..." />}
        </section>

        <section id="weather" className="section">
          <div className="section-header">
            <div>
              <p className="eyebrow">Current Conditions</p>
              <h2>Weather Dashboard</h2>
            </div>
            {currentWeather && (
              <div className="dashboard-actions">
                <button className="ghost-button" onClick={refresh} disabled={loading}>
                  {loading ? 'Refreshing…' : 'Refresh weather'}
                </button>
              </div>
            )}
          </div>

          {loading && currentWeather && <Loading inline label="Updating weather data..." />}
          {loading && !currentWeather && <SkeletonDashboard />}

          {!loading && !currentWeather && !error && (
            <div className="empty-inline glass-card">
              <p>No weather data loaded yet. Search for a city above to view current conditions and metrics.</p>
            </div>
          )}

          {currentWeather && (
            <>
              <CurrentWeather
                data={currentWeather}
                unit={unit}
                iconType={iconType}
                lastUpdated={lastUpdated}
                isFavorite={isFavorite(location)}
                onToggleFavorite={() => {
                  if (!location) return;
                  if (isFavorite(location)) removeFavorite(location);
                  else addFavorite(location);
                }}
                onRefresh={refresh}
                loading={loading}
              />
              <WeatherMetrics data={currentWeather} unit={unit} />
            </>
          )}
        </section>

        <section id="forecast" className="section">
          <div className="section-header">
            <div>
              <p className="eyebrow">Outlook</p>
              <h2>Five-Day Forecast</h2>
            </div>
            {locationLabel && <p className="section-subtitle">Local forecast for {locationLabel}</p>}
          </div>

          {loading && !dailyForecast.length && <SkeletonDashboard variant="forecast" />}
          {!loading && !dailyForecast.length && (
            <div className="empty-inline glass-card">
              <p>Forecast data will appear here after you search for a location.</p>
            </div>
          )}
          {dailyForecast.length > 0 && <Forecast days={dailyForecast} unit={unit} />}
        </section>

        <section id="map" className="section">
          <div className="section-header">
            <div>
              <p className="eyebrow">Location</p>
              <h2>Interactive Weather Map</h2>
            </div>
            <p className="section-subtitle">Select a location on the map to update the dashboard.</p>
          </div>
          <WeatherMap
            location={location}
            onSelectLocation={handleMapLocationSelect}
          />
        </section>

        <section id="settings" className="section">
          <div className="section-header">
            <div>
              <p className="eyebrow">Preferences</p>
              <h2>Settings & Saved Places</h2>
            </div>
          </div>

          <div className="settings-grid">
            <div className="glass-card settings-panel">
              <div className="panel-header">
                <h3>Settings</h3>
                <button className="ghost-button small" onClick={() => setSettingsOpen((v) => !v)}>
                  {settingsOpen ? 'Hide' : 'Show'}
                </button>
              </div>
              {settingsOpen && (
                <div className="settings-body">
                  <div className="setting-row">
                    <div>
                      <h4>Temperature unit</h4>
                      <p>Switch between Celsius and Fahrenheit. All metrics and forecast cards update instantly.</p>
                    </div>
                    <div className="segmented-control" role="group" aria-label="Temperature unit">
                      <button
                        className={unit === 'metric' ? 'active' : ''}
                        onClick={() => setUnit('metric')}
                        type="button"
                      >
                        °C
                      </button>
                      <button
                        className={unit === 'imperial' ? 'active' : ''}
                        onClick={() => setUnit('imperial')}
                        type="button"
                      >
                        °F
                      </button>
                    </div>
                  </div>

                  <div className="setting-row">
                    <div>
                      <h4>Wind speed</h4>
                      <p>{unit === 'imperial' ? 'Displaying wind speed in mph.' : 'Displaying wind speed in km/h.'}</p>
                    </div>
                    <button className="ghost-button" type="button" onClick={toggleUnit}>
                      Toggle units
                    </button>
                  </div>

                  <div className="setting-row">
                    <div>
                      <h4>Status</h4>
                      <p>Live telemetry status: <strong>{status}</strong>{lastUpdated ? ` • Last updated ${new Date(lastUpdated).toLocaleString()}` : ''}</p>
                    </div>
                    <button className="ghost-button" type="button" onClick={refresh} disabled={!currentWeather || loading}>
                      Refresh
                    </button>
                  </div>
                </div>
              )}
            </div>

            <FavoriteCities
              favorites={favorites}
              recents={recents}
              onSelect={handleSelectFavorite}
              onRemoveFavorite={removeFavorite}
            />
          </div>
        </section>
      </main>

      <footer className="footer">
        <p>ATMOS — Live weather telemetry powered by OpenWeatherMap{hasGoogleMapsApiKeySafe() ? ' and Google Maps' : ''}.</p>
      </footer>
    </div>
  );
}

function hasGoogleMapsApiKeySafe() {
  const key = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  return Boolean(key && key !== 'your_google_maps_api_key');
}

export default App;
