# ATMOS — Live Weather Telemetry

**Feel the atmosphere. Discover your world.**

ATMOS is a production-quality, responsive weather telemetry dashboard built with React and Vite. It delivers real-time weather conditions and a five-day outlook for any city worldwide using the OpenWeatherMap API, with optional Google Maps integration for interactive location selection.

## Project overview

ATMOS provides a premium, glassmorphism-styled weather experience with live telemetry status, dynamic weather-based visuals, unit conversion, saved locations, and resilient error handling. The app is designed to work with real API data and to surface clear setup or service messages instead of blank states when data is unavailable.

## Features

- **Global city search** with quick suggestions (Kolkata, London, Tokyo, New York, Dubai), recent searches, loading state, keyboard Enter support, and input/error handling.
- **Optional Google Places autocomplete** for city suggestions when Google Maps/Places is configured.
- **Current weather dashboard**: temperature, feels-like, condition/description, high/low, humidity, wind speed and direction, atmospheric pressure, visibility, sunrise, and sunset with dynamic weather icons.
- **Five-day forecast** generated with `Array.map()` from OpenWeatherMap 3-hour data grouped by local calendar date (selecting a daytime reading where possible), including min/max temperatures and a temperature indicator.
- **Dynamic weather backgrounds** for sunny, cloudy, rainy, snowy, and night conditions with smooth transitions.
- **Temperature and wind unit conversion** (°C/°F, km/h/mph) applied instantly across current metrics and forecast cards without a new search.
- **Interactive weather map** (optional): displays the selected city marker, allows clicking the map to choose a new location, and updates the dashboard. Includes graceful fallback when Maps is unavailable/unconfigured.
- **Current location weather** via browser geolocation (permission requested only after user action).
- **Favorite cities and recent searches** persisted in `localStorage`.
- **Refresh and last-updated timestamp** with live status indicator in the navigation bar.
- **Settings panel** for unit preferences and status/refresh controls.
- **Robust states**: loading spinner, skeleton cards, invalid city handling, network/API/rate-limit/service errors, missing API key warning, retry actions, and an initial empty state.
- **Responsive UI** with mobile-friendly navigation.

## Screenshots

Add screenshots of the application here (recommended):

- `docs/screenshots/home.png` — Home/search and hero view
- `docs/screenshots/weather-dashboard.png` — Current conditions and metrics
- `docs/screenshots/forecast.png` — Five-day forecast
- `docs/screenshots/map.png` — Interactive map / fallback state
- `docs/screenshots/mobile.png` — Mobile layout

Example markdown:

```md
![ATMOS Home](docs/screenshots/home.png)
![ATMOS Dashboard](docs/screenshots/weather-dashboard.png)
```

## Technology stack

### Frontend
- React.js
- Vite
- JavaScript (ES6+)
- HTML5
- CSS3
- Lucide React icons

### APIs
- OpenWeatherMap Current Weather API (`/data/2.5/weather`)
- OpenWeatherMap 5 Day / 3 Hour Forecast API (`/data/2.5/forecast`)
- Google Maps JavaScript API (optional map integration)
- Google Places API (optional city autocomplete)

## Architecture explanation

The project follows a modular, service-oriented frontend structure:

```text
atmos-weather/
├── public/
├── src/
│   ├── components/      # Presentational and UI feature components
│   │   ├── Navbar.jsx
│   │   ├── SearchBar.jsx
│   │   ├── CurrentWeather.jsx
│   │   ├── WeatherMetrics.jsx
│   │   ├── Forecast.jsx
│   │   ├── WeatherMap.jsx
│   │   ├── FavoriteCities.jsx
│   │   ├── Loading.jsx
│   │   └── ErrorMessage.jsx
│   ├── services/        # External API integrations and script loading
│   │   ├── weatherApi.js
│   │   └── mapsApi.js
│   ├── hooks/           # Application state and data-fetch orchestration
│   │   └── useWeather.js
│   ├── utils/           # Formatting, conversions, grouping, theming helpers
│   │   └── weatherHelpers.js
│   ├── App.jsx          # Composition, navigation/sections, feature wiring
│   ├── main.jsx         # React entry point
│   └── styles.css       # Global design system and responsive styles
├── .env.example
├── .gitignore
├── index.html
├── package.json
└── README.md
```

### Key design choices
- **`weatherApi.js`** centralizes OpenWeatherMap requests with `async/await`, `try/catch`, response-status validation, JSON parsing, and typed error handling (missing key, not found, unauthorized, rate limit, network, service unavailable).
- **`mapsApi.js`** lazily loads the Google Maps JavaScript API (with Places library) only when configured, enabling graceful fallback when unavailable.
- **`useWeather.js`** manages telemetry state (current weather, forecast, grouped daily forecast, loading/error/status, last updated), persistence (unit, favorites, recents in `localStorage`), and actions (search by city/coords, geolocation, refresh/retry, favorites management). Unit changes are applied client-side without refetching.
- **`weatherHelpers.js`** provides pure utilities for unit conversion, formatting (time/wind/visibility/pressure), icon/theme selection, and forecast grouping by local calendar date.
- **Components** focus on rendering and interaction; `App.jsx` composes sections and in-page navigation.

## Installation instructions

### Prerequisites
- Node.js 18+ (recommended: latest LTS)
- npm 9+
- An OpenWeatherMap API key (required for live weather)
- A Google Maps JavaScript API key (optional, for map/Places autocomplete)

### Install
```bash
git clone <your-repository-url>
cd atmos-weather
npm install
```

## Environment variable configuration

Create a `.env` file in the project root (same level as `package.json`) based on `.env.example`:

```env
VITE_OPENWEATHER_API_KEY=your_openweathermap_api_key
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key
```

- `VITE_OPENWEATHER_API_KEY` — **required** for live weather and forecast data.
- `VITE_GOOGLE_MAPS_API_KEY` — **optional** for interactive map and Places autocomplete. If omitted, the app shows a graceful map fallback and continues to work for search/forecast features.

> **Important:** Vite environment variables prefixed with `VITE_` are embedded in the client bundle and visible in the browser. For production deployments that require protected/shared API credentials, use a backend or serverless API proxy and keep secrets server-side.

## API setup

### OpenWeatherMap
1. Create an account at [OpenWeatherMap](https://openweathermap.org/).
2. Generate an API key from your account dashboard.
3. Add the key to `.env` as `VITE_OPENWEATHER_API_KEY`.
4. Ensure your plan has access to:
   - Current Weather Data: `https://api.openweathermap.org/data/2.5/weather`
   - 5 Day / 3 Hour Forecast: `https://api.openweathermap.org/data/2.5/forecast`
5. New keys may take a short time to activate.

### Google Maps (optional)
1. Create/select a project in [Google Cloud Console](https://console.cloud.google.com/).
2. Enable **Maps JavaScript API** (and **Places API** for autocomplete).
3. Create an API key and restrict it appropriately (HTTP referrers, API restrictions).
4. Add the key to `.env` as `VITE_GOOGLE_MAPS_API_KEY`.

## How to run locally

1. Configure `.env` as described above.
2. Start the development server:
   ```bash
   npm run dev
   ```
3. Open the URL shown in the terminal (typically `http://localhost:5173`).
4. If you change `.env`, restart the dev server.

## Production build instructions

Create an optimized production build:

```bash
npm run build
```

Preview the production build locally:

```bash
npm run preview
```

The compiled output is generated in the `dist/` directory.

## Deployment instructions

ATMOS is a static Vite/React build and can be deployed to most static hosting platforms.

### General steps
1. Set environment variables in your hosting provider's build settings:
   - `VITE_OPENWEATHER_API_KEY`
   - `VITE_GOOGLE_MAPS_API_KEY` (optional)
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Ensure SPA routing fallback is configured if needed (this app uses in-page sections, but a standard SPA fallback to `index.html` is safe).

### Platform examples
- **Vercel**: Import the repo, set env vars, framework preset Vite, output `dist`.
- **Netlify**: Build `npm run build`, publish `dist`, add env vars in Site settings.
- **GitHub Pages**: Build and deploy `dist` via Actions or `gh-pages` (configure `base` in `vite.config.js` if serving from a subpath).

> Reminder: client-side `VITE_*` keys are exposed to users. Use a proxy/serverless function for sensitive production credential handling.

## GitHub upload instructions

1. Initialize git (if not already):
   ```bash
   git init
   git add .
   git commit -m "Initial commit: ATMOS live weather telemetry app"
   ```
2. Create a new repository on GitHub.
3. Add the remote and push:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git push -u origin main
   ```
4. Confirm `.env` is **not** committed (it is excluded by `.gitignore`). Share `.env.example` for configuration.

## Notes

- Weather API responses are fetched in metric units and converted in the UI for display preferences.
- Forecast days are derived by grouping 3-hour intervals by local calendar date and selecting a daytime reading when possible.
- If no OpenWeatherMap API key is configured, the app displays a clear setup message and does not show fake live data.
